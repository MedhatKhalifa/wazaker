import 'package:flutter/material.dart';

var lightThemeData =
    ThemeData(brightness: Brightness.dark, fontFamily: 'myarabic');
// primaryColor: Colors.blue,
// textTheme:  TextTheme(button: TextStyle(color: Colors.white70)),
// brightness: Brightness.light,
// accentColor: Colors.blue);

var darkThemeData =
    ThemeData(brightness: Brightness.light, fontFamily: 'myarabic');

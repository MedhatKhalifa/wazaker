enum MenuState { home, fav, profile }
enum category { Cat, Dog, Service, Best_Selling }
